===============
Logo de empresa
===============

Añade el logo de la empresa como un campo binario.
