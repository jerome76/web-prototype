Company Logo Module
###################

The company_logo module adds the logo of a company as a binary field.
